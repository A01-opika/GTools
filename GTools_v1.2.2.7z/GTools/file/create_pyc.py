import GTools
print('.pyc OK!')
print('verify in progress...')
if GTools.IsPrime(2) == True:
    print('Verify success!')
else:
    print('Verify failed!')