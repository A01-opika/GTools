import GTools as gt


# Example 1
gt.sprint("=============== Example 1 ===============", delay = 0.05)
gt.sprint(gt.IsPrime(int(input("Enter a number: "))), delay = 0.05)

# Example 2
gt.sprint("=============== Example 1 ===============", delay = 0.05)
gt.sprint('Library Inforamtion: ')
information = gt.Inf(use_sprint = True, sp_delay = 0.05)
information.info()

